#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include "board.h"
#include "ti/driverlib/m0p/dl_core.h"

void uart0_send_char(char ch)
{
    //当串口0忙的时候等待，不忙的时候再发送传进来的字符
    while( DL_UART_Main_isBusy(UART_0_INST) == true );
    //发送单个字符
    DL_UART_Main_transmitData(UART_0_INST, ch);
}
//串口发送字符串
void uart0_send_string(char* str)
{
    //当前字符串地址不在结尾 并且 字符串首地址不为空
    while(*str!=0&&str!=0)
    {
        //发送字符串首地址中的字符，并且在发送完成之后首地址自增
        uart0_send_char(*str++);
    }
}

/* 将c库的printf函数重新定位到USART */
int fputc(int ch, FILE *f)
{
    DL_UART_Main_transmitDataBlocking(UART_K230_INST, ch);
    return ch;
}

int fputs(const char *restrict s, FILE *restrict stream)
{
  uint16_t i, len;
  len = strlen(s);  
    for (i = 0; i < len; i++) {
    DL_UART_Main_transmitDataBlocking(UART_K230_INST, s[i]);
    }
  return len;
}

int puts(const char* _ptr)
{
    int count = fputs(_ptr, stdout);
    count += fputs("\n",stdout);
    return count;
}

int LOG_Debug_Out(const char* __file, const char* __func, int __line, const char* format, ...)
{
    va_list args;
    va_start(args, format);

    // 前缀信息
    char log_buff[64] = {0};
    sprintf(log_buff, "[%s Func:%s Line:%d] ",__file,__func,__line);

    // 创建一个足够大的缓冲区来存储格式化后的字符串
    char buffer[512] = {0};
    strcpy(buffer, log_buff); // 使用strcpy来复制前缀信息
    int len = vsnprintf(buffer + strlen(buffer), sizeof(buffer) - strlen(buffer), format, args); // 追加到buffer中

    va_end(args);

    // 发送格式化后的字符串
    char temp_buff[] = "\r\n";
    strcat(buffer, temp_buff);
    uart0_send_string(buffer);
    return len;
}




