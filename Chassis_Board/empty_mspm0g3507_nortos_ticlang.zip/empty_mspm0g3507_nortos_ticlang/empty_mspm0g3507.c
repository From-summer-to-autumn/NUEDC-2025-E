/*
 * Copyright (c) 2023, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include "stdio.h"
#include "board.h"
#include "interrupts.h"
#include "clock.h"
#include "servo.h"
#include "oled_hardware_i2c.h"
#include "PID.h"

#define RX_BUFFER_SIZE 13
uint8_t flag_servo = 0;
volatile uint8_t gReceiveBuffer[RX_BUFFER_SIZE];
volatile uint8_t gByteCount = 0;
pid_type_def x_pid, y_pid;
int servo_1 = 1500, servo_2 = 1500;
int error_x, error_y, x_set, y_set, x_ref, y_ref; 
fp32 PID_error_x[3]={0.10f,0.02f,0.0f};
fp32 PID_error_y[3]={0.10f,0.02f,0.0f};

int main(void)
{
    SYSCFG_DL_init();
    SysTick_Init();
    NVIC_EnableIRQ(1);
    NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
    OLED_Init();
    OLED_Clear();
    PID_init(&x_pid, PID_DELTA, PID_error_x, 200, 20);
    PID_init(&y_pid, PID_DELTA, PID_error_y, 200, 20);
    while (1) {
        OLED_ShowNum(0, 0, x_set, 3, 16);
        OLED_ShowNum(40, 0, y_set, 3, 16);
        OLED_ShowNum(0, 3, x_ref, 3, 16);
        OLED_ShowNum(40, 3, y_ref, 3, 16);
        if(flag_servo == 1)
        {
            loop_draw_square_on_plane();
            mspm0_delay_ms(2000);
            loop_draw_circle_on_plane();
            mspm0_delay_ms(2000);
            loop_draw_sine_wave();
            mspm0_delay_ms(2000);
        }
    }
}


void GROUP1_IRQHandler(void)
{
	if((DL_GPIO_getEnabledInterruptStatus(Key_PORT,Key_B16_PIN) & Key_B16_PIN) != 0)
	{
        DL_GPIO_clearPins(LED_PORT,LED_B22_PIN);
		set_servo_1(1500);
        set_servo_2(1550);
        DL_GPIO_clearInterruptStatus(Key_PORT, Key_B16_PIN);
	}

	else if((DL_GPIO_getEnabledInterruptStatus(Key_PORT,Key_B20_PIN) & Key_B20_PIN) != 0)
	{
        DL_GPIO_setPins(LED_PORT,LED_B22_PIN);
		set_servo_1(1500);
        set_servo_2(1450);
        DL_GPIO_clearInterruptStatus(Key_PORT, Key_B20_PIN);
	}

	else if((DL_GPIO_getEnabledInterruptStatus(Key_PORT,Key_B4_PIN) & Key_B4_PIN) != 0)
	{
        DL_GPIO_clearPins(LED_PORT,LED_B22_PIN);
		set_servo_1(1500);
        set_servo_2(1500);
        DL_GPIO_clearInterruptStatus(Key_PORT, Key_B4_PIN);
	}

    else if((DL_GPIO_getEnabledInterruptStatus(Key_PORT,Key_B15_PIN) & Key_B15_PIN) != 0)
	{
        DL_GPIO_setPins(LED_PORT,LED_B22_PIN);
		flag_servo = 1;
        DL_GPIO_clearInterruptStatus(Key_PORT, Key_B15_PIN);			
	}
}

void UART_0_INST_IRQHandler(void)
{
    switch (DL_UART_Main_getPendingInterrupt(UART_0_INST)) {
        case DL_UART_MAIN_IIDX_RX:
            // Read the received byte and store it in our buffer
            gReceiveBuffer[gByteCount] = DL_UART_Main_receiveData(UART_0_INST);
            gByteCount++;

            if (gByteCount == RX_BUFFER_SIZE) {
                gByteCount = 0;
                if(gReceiveBuffer[0] == 'a'){
                    x_set = 100*(gReceiveBuffer[1]-'0') + 10*(gReceiveBuffer[2]-'0') + (gReceiveBuffer[3]-'0');
                    y_set = 100*(gReceiveBuffer[4]-'0') + 10*(gReceiveBuffer[5]-'0') + (gReceiveBuffer[6]-'0');
                    x_ref = 100*(gReceiveBuffer[7]-'0') + 10*(gReceiveBuffer[8]-'0') + (gReceiveBuffer[9]-'0');
                    y_ref = 100*(gReceiveBuffer[10]-'0') + 10*(gReceiveBuffer[11]-'0') + (gReceiveBuffer[12]-'0');
                    PID_calc(&x_pid, x_ref - x_set, 0);
                    PID_calc(&y_pid, y_ref - y_set, 0);
                    set_servo_1(1500 - x_pid.out);
                    set_servo_2(1650 - y_pid.out);
                }
            }
            break;
        default:
            break;
    }
}