################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../MSPM0/clock.c \
../MSPM0/interrupts.c 

C_DEPS += \
./MSPM0/clock.d \
./MSPM0/interrupts.d 

OBJS += \
./MSPM0/clock.o \
./MSPM0/interrupts.o 

OBJS__QUOTED += \
"MSPM0\clock.o" \
"MSPM0\interrupts.o" 

C_DEPS__QUOTED += \
"MSPM0\clock.d" \
"MSPM0\interrupts.d" 

C_SRCS__QUOTED += \
"../MSPM0/clock.c" \
"../MSPM0/interrupts.c" 


