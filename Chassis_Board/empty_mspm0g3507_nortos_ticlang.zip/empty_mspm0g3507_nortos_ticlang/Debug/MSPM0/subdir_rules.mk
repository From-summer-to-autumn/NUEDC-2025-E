################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
MSPM0/%.o: ../MSPM0/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"D:/software/ti/ccs/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang" -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang/Debug" -I"C:/TI/mspm0_sdk_2_05_01_00/source/third_party/CMSIS/Core/Include" -I"C:/TI/mspm0_sdk_2_05_01_00/source" -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang/MSPM0" -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang/servo" -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang/Board" -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang/OLED" -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang/PID" -gdwarf-3 -MMD -MP -MF"MSPM0/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/happyfish/workspace_ccstheia/empty_mspm0g3507_nortos_ticlang/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


