/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000



/* Defines for servo_1 */
#define servo_1_INST                                                       TIMG6
#define servo_1_INST_IRQHandler                                 TIMG6_IRQHandler
#define servo_1_INST_INT_IRQN                                   (TIMG6_INT_IRQn)
#define servo_1_INST_CLK_FREQ                                            1000000
/* GPIO defines for channel 0 */
#define GPIO_servo_1_C0_PORT                                               GPIOA
#define GPIO_servo_1_C0_PIN                                       DL_GPIO_PIN_29
#define GPIO_servo_1_C0_IOMUX                                     (IOMUX_PINCM4)
#define GPIO_servo_1_C0_IOMUX_FUNC                    IOMUX_PINCM4_PF_TIMG6_CCP0
#define GPIO_servo_1_C0_IDX                                  DL_TIMER_CC_0_INDEX

/* Defines for servo_2 */
#define servo_2_INST                                                       TIMG7
#define servo_2_INST_IRQHandler                                 TIMG7_IRQHandler
#define servo_2_INST_INT_IRQN                                   (TIMG7_INT_IRQn)
#define servo_2_INST_CLK_FREQ                                            1000000
/* GPIO defines for channel 0 */
#define GPIO_servo_2_C0_PORT                                               GPIOA
#define GPIO_servo_2_C0_PIN                                       DL_GPIO_PIN_26
#define GPIO_servo_2_C0_IOMUX                                    (IOMUX_PINCM59)
#define GPIO_servo_2_C0_IOMUX_FUNC                   IOMUX_PINCM59_PF_TIMG7_CCP0
#define GPIO_servo_2_C0_IDX                                  DL_TIMER_CC_0_INDEX




/* Defines for I2C_OLED */
#define I2C_OLED_INST                                                       I2C1
#define I2C_OLED_INST_IRQHandler                                 I2C1_IRQHandler
#define I2C_OLED_INST_INT_IRQN                                     I2C1_INT_IRQn
#define I2C_OLED_BUS_SPEED_HZ                                             400000
#define GPIO_I2C_OLED_SDA_PORT                                             GPIOA
#define GPIO_I2C_OLED_SDA_PIN                                     DL_GPIO_PIN_16
#define GPIO_I2C_OLED_IOMUX_SDA                                  (IOMUX_PINCM38)
#define GPIO_I2C_OLED_IOMUX_SDA_FUNC                   IOMUX_PINCM38_PF_I2C1_SDA
#define GPIO_I2C_OLED_SCL_PORT                                             GPIOA
#define GPIO_I2C_OLED_SCL_PIN                                     DL_GPIO_PIN_17
#define GPIO_I2C_OLED_IOMUX_SCL                                  (IOMUX_PINCM39)
#define GPIO_I2C_OLED_IOMUX_SCL_FUNC                   IOMUX_PINCM39_PF_I2C1_SCL


/* Defines for UART_K230 */
#define UART_K230_INST                                                     UART3
#define UART_K230_INST_FREQUENCY                                        20000000
#define UART_K230_INST_IRQHandler                               UART3_IRQHandler
#define UART_K230_INST_INT_IRQN                                   UART3_INT_IRQn
#define GPIO_UART_K230_RX_PORT                                             GPIOB
#define GPIO_UART_K230_TX_PORT                                             GPIOB
#define GPIO_UART_K230_RX_PIN                                     DL_GPIO_PIN_13
#define GPIO_UART_K230_TX_PIN                                     DL_GPIO_PIN_12
#define GPIO_UART_K230_IOMUX_RX                                  (IOMUX_PINCM30)
#define GPIO_UART_K230_IOMUX_TX                                  (IOMUX_PINCM29)
#define GPIO_UART_K230_IOMUX_RX_FUNC                   IOMUX_PINCM30_PF_UART3_RX
#define GPIO_UART_K230_IOMUX_TX_FUNC                   IOMUX_PINCM29_PF_UART3_TX
#define UART_K230_BAUD_RATE                                             (115200)
#define UART_K230_IBRD_20_MHZ_115200_BAUD                                   (10)
#define UART_K230_FBRD_20_MHZ_115200_BAUD                                   (54)
/* Defines for UART_0 */
#define UART_0_INST                                                        UART1
#define UART_0_INST_FREQUENCY                                           10000000
#define UART_0_INST_IRQHandler                                  UART1_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART1_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOA
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                         DL_GPIO_PIN_9
#define GPIO_UART_0_TX_PIN                                         DL_GPIO_PIN_8
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM20)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM19)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM20_PF_UART1_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM19_PF_UART1_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_10_MHZ_115200_BAUD                                       (5)
#define UART_0_FBRD_10_MHZ_115200_BAUD                                      (27)





/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOB)

/* Defines for B22: GPIOB.22 with pinCMx 50 on package pin 21 */
#define LED_B22_PIN                                             (DL_GPIO_PIN_22)
#define LED_B22_IOMUX                                            (IOMUX_PINCM50)
/* Port definition for Pin Group Key */
#define Key_PORT                                                         (GPIOB)

/* Defines for B4: GPIOB.4 with pinCMx 17 on package pin 52 */
// pins affected by this interrupt request:["B4","B15","B16","B20"]
#define Key_INT_IRQN                                            (GPIOB_INT_IRQn)
#define Key_INT_IIDX                            (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define Key_B4_IIDX                                          (DL_GPIO_IIDX_DIO4)
#define Key_B4_PIN                                               (DL_GPIO_PIN_4)
#define Key_B4_IOMUX                                             (IOMUX_PINCM17)
/* Defines for B15: GPIOB.15 with pinCMx 32 on package pin 3 */
#define Key_B15_IIDX                                        (DL_GPIO_IIDX_DIO15)
#define Key_B15_PIN                                             (DL_GPIO_PIN_15)
#define Key_B15_IOMUX                                            (IOMUX_PINCM32)
/* Defines for B16: GPIOB.16 with pinCMx 33 on package pin 4 */
#define Key_B16_IIDX                                        (DL_GPIO_IIDX_DIO16)
#define Key_B16_PIN                                             (DL_GPIO_PIN_16)
#define Key_B16_IOMUX                                            (IOMUX_PINCM33)
/* Defines for B20: GPIOB.20 with pinCMx 48 on package pin 19 */
#define Key_B20_IIDX                                        (DL_GPIO_IIDX_DIO20)
#define Key_B20_PIN                                             (DL_GPIO_PIN_20)
#define Key_B20_IOMUX                                            (IOMUX_PINCM48)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_servo_1_init(void);
void SYSCFG_DL_servo_2_init(void);
void SYSCFG_DL_I2C_OLED_init(void);
void SYSCFG_DL_UART_K230_init(void);
void SYSCFG_DL_UART_0_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
