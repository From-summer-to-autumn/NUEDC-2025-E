################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../OLED/oled_hardware_i2c.c 

C_DEPS += \
./OLED/oled_hardware_i2c.d 

OBJS += \
./OLED/oled_hardware_i2c.o 

OBJS__QUOTED += \
"OLED\oled_hardware_i2c.o" 

C_DEPS__QUOTED += \
"OLED\oled_hardware_i2c.d" 

C_SRCS__QUOTED += \
"../OLED/oled_hardware_i2c.c" 


