################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../servo/servo.c 

C_DEPS += \
./servo/servo.d 

OBJS += \
./servo/servo.o 

OBJS__QUOTED += \
"servo\servo.o" 

C_DEPS__QUOTED += \
"servo\servo.d" 

C_SRCS__QUOTED += \
"../servo/servo.c" 


