#include "servo.h"
#include "math.h"
#include "clock.h"

void set_servo_1(uint32_t value)
{
    DL_TimerG_setCaptureCompareValue(servo_1_INST,value,GPIO_servo_1_C0_IDX);
    // if(value < 500) value = 500;
    // if(value > 2500)value = 2500;
}

void set_servo_2(uint32_t value)
{
    DL_TimerG_setCaptureCompareValue(servo_2_INST,value,GPIO_servo_2_C0_IDX);
}

void set_servos(uint32_t pwm1, uint32_t pwm2)
{
    DL_TimerG_setCaptureCompareValue(servo_1_INST,pwm1,GPIO_servo_1_C0_IDX);
    DL_TimerG_setCaptureCompareValue(servo_2_INST,pwm2,GPIO_servo_2_C0_IDX);
}


const float kServoPi = 3.14159265f;

// 俯仰舵机 (PWM1)
const float up_servo_high_pwm = 2560; // 对应 +90度 (PI/2)
const float up_servo_mid_pwm = 1560; // 对应 0度
const float up_servo_low_pwm = 560;  // 对应 -90度 (-PI/2)

// 航向舵机 (PWM2)
const float dw_servo_left_pwm = 2217;  // 对应 180度 (PI)
const float dw_servo_right_pwm = 783;   // 对应 0度

// 云台旋转半径 (mm)
const float r = 72.0f;
// --------------------------------------------------

/**
 * @brief 逆运动学解算函数：通过坐标计算PWM值
 * @param x 目标点的x坐标
 * @param y 目标点的y坐标
 * @param z 目标点的z坐标
 * @param out_pwm1 指向俯仰舵机PWM输出值的指针
 * @param out_pwm2 指向航向舵机PWM输出值的指针
 * @return 如果坐标可达，返回true；否则返回false
 */
bool calculate_pwm_from_coords(float x, float y, float z, uint16_t* out_pwm2, uint16_t* out_pwm1) {
    
    // --- 步骤1: 检查目标点是否在云台可达的球面上 ---
    // 理论上，目标点必须在以r为半径的球面上，即 x^2+y^2+z^2 = r^2
    // 为了增加容错性，我们可以将目标点“投影”到球面上
    float distance = sqrt(x*x + y*y + z*z);
    if (distance < 1e-6) { // 避免除以零，原点不可达
        return false;
    }
    // 将坐标归一化到球面上
    x = x * r / distance;
    y = y * r / distance;
    z = z * r / distance;

    // --- 步骤2: 从坐标 (x,y,z) 反解出角度 (alpha, beta) ---
    float alpha, beta;

    // 计算俯仰角 alpha
    // asin的输入值必须在 [-1, 1] 之间
    float asin_arg = z / r;
    if (asin_arg > 1.0f) asin_arg = 1.0f;
    if (asin_arg < -1.0f) asin_arg = -1.0f;
    alpha = asin(asin_arg);

    // 计算航向角 beta
    beta = atan2(y, x);

    // --- 步骤3: 从角度 (alpha, beta) 反解出 PWM 值 ---
    float pwm1_f = (alpha / (kServoPi / 2.0f)) * (up_servo_high_pwm - up_servo_mid_pwm) + up_servo_mid_pwm;
    // 注意：这里的beta范围是[0, PI]，所以除以kServoPi
    float pwm2_f = (beta / kServoPi) * (dw_servo_left_pwm - dw_servo_right_pwm) + dw_servo_right_pwm;

    // --- 步骤4: 检查PWM值是否在舵机有效范围内 ---
    if (pwm1_f > up_servo_high_pwm) pwm1_f = up_servo_high_pwm;
    if (pwm1_f < up_servo_low_pwm) pwm1_f = up_servo_low_pwm;

    if (pwm2_f > dw_servo_left_pwm) pwm2_f = dw_servo_left_pwm;
    if (pwm2_f < dw_servo_right_pwm) pwm2_f = dw_servo_right_pwm;

    // 将计算出的浮点数PWM转换为无符号16位整数
    *out_pwm1 = (uint16_t)pwm1_f;
    *out_pwm2 = (uint16_t)pwm2_f;
    return true;
}

void loop_draw_square_on_plane() {

    // --- 绘图参数定义 ---
    const float DISTANCE_TO_PAPER = 350.0f; // 纸张离云台的距离 (mm)，这是固定的y值
    const float SQUARE_SIZE = 80.0f;        // 正方形边长 (mm)
    const int   POINTS_PER_SIDE = 50;       // 每条边画50个点

    float half_size = SQUARE_SIZE / 2.0f;

    // 定义正方形的四个顶点 (u,v) 坐标
    float corners[4][2] = {
        {-half_size, -half_size}, // 左下
        { half_size, -half_size}, // 右下
        { half_size,  half_size}, // 右上
        {-half_size,  half_size}  // 左上
    };

    float start_u = corners[0][0];
    float start_v = corners[0][1];

    float start_target_x = start_u;
    float start_target_y = DISTANCE_TO_PAPER;
    float start_target_z = start_v;

    // 2. 计算起点PWM
    uint16_t start_pwm1, start_pwm2;
    if (calculate_pwm_from_coords(start_target_x, start_target_y, start_target_z, &start_pwm1, &start_pwm2)) {
        set_servos(start_pwm1, start_pwm2);
        mspm0_delay_ms(1000); // 等待1秒，确保云台已经到达起点
    }
    
    // 依次画四条边
    for (int side = 0; side < 4; ++side) {
        float u_start = corners[side][0];
        float v_start = corners[side][1];
        
        float u_end = corners[(side + 1) % 4][0];
        float v_end = corners[(side + 1) % 4][1];

        // 在两点之间进行线性插值
        for (int i = 0; i <= POINTS_PER_SIDE; ++i) {
            
            // 1. 计算当前点的2D绘图坐标 (u, v)
            float u = u_start + (u_end - u_start) * i / POINTS_PER_SIDE;
            float v = v_start + (v_end - v_start) * i / POINTS_PER_SIDE;

            // 2. 将2D绘图坐标 (u,v) 映射到 3D空间坐标 (x,y,z)
            float target_x = u;
            float target_y = DISTANCE_TO_PAPER; // y坐标是固定的！
            float target_z = v;

            // 3. 调用逆解算函数，得到PWM值
            uint16_t pwm1, pwm2;
            if (calculate_pwm_from_coords(target_x, target_y, target_z, &pwm1, &pwm2)) {
                set_servos(pwm1, pwm2);
            }
            
            mspm0_delay_ms(20);
        }
    }
}

void loop_draw_circle_on_plane() {

    // --- 绘图参数定义 ---
    const float DISTANCE_TO_PAPER = 350.0f; // 纸张离云台的距离 (mm)，这是固定的y值
    const float CIRCLE_RADIUS = 70.0f;      // 要画的圆的半径 (mm)
    const int   NUM_CIRCLE_STEPS = 600;     // 用120个小线段来逼近一个圆，值越大圆越平滑
    const float kTwoPi = 2.0f * 3.14159265f;

    // 圆心在纸张上的位置 (u,v)
    const float CIRCLE_CENTER_U = 0.0f;
    const float CIRCLE_CENTER_V = 0.0f;

    float start_u = CIRCLE_CENTER_U + CIRCLE_RADIUS;
    float start_v = CIRCLE_CENTER_V;

    float start_target_x = start_u;
    float start_target_y = DISTANCE_TO_PAPER;
    float start_target_z = start_v;

    // 2. 计算起点PWM
    uint16_t start_pwm1, start_pwm2;
    if (calculate_pwm_from_coords(start_target_x, start_target_y, start_target_z, &start_pwm1, &start_pwm2)) {
        set_servos(start_pwm1, start_pwm2);
        mspm0_delay_ms(1000); // 等待1秒，确保云台已经到达起点
    }

    // --- 循环绘制圆上的每一个点 ---
    for (int i = 0; i <= NUM_CIRCLE_STEPS; ++i) {
        
        // 1. 计算当前的角度 theta
        float theta = kTwoPi * i / NUM_CIRCLE_STEPS;

        // 2. 使用圆的参数方程，计算当前点的2D绘图坐标 (u, v)
        float u = CIRCLE_CENTER_U + CIRCLE_RADIUS * cos(theta);
        float v = CIRCLE_CENTER_V + CIRCLE_RADIUS * sin(theta);

        // 3. 将2D绘图坐标 (u,v) 映射到 3D空间坐标 (x,y,z)
        float target_x = u;
        float target_y = DISTANCE_TO_PAPER; // y坐标是固定的！
        float target_z = v;

        // 4. 调用逆解算函数，得到PWM值
        uint16_t pwm1, pwm2;
        if (calculate_pwm_from_coords(target_x, target_y, target_z, &pwm1, &pwm2)) {
            set_servos(pwm1, pwm2); 
            // printf("Theta: %.2f, u: %.2f, v: %.2f -> PWMs: %u, %u\n", theta, u, v, pwm1, pwm2);
        }
        
            mspm0_delay_ms(20);
    }
}

void loop_draw_sine_wave() {

    // --- 绘图参数定义 ---
    const float DISTANCE_TO_PAPER = 350.0f; // 纸张离云台的距离 (mm)
    const float WAVE_WIDTH      = 250.0f;   // 曲线在墙上的总物理宽度 (mm)
    const float WAVE_AMPLITUDE  = 40.0f;    // 曲线的振幅 (mm)，即波峰到基线的距离
    const float NUM_CYCLES      = 4.0f;     // 要在指定的宽度内绘制多少个完整的周期
    const int   NUM_SINE_STEPS  = 600;      // 插值步数，决定了曲线的平滑度
    const float kTwoPi = 2.0f * 3.14159265f;

    // 曲线的中心位置 (u,v)
    const float SINE_CENTER_U = 0.0f;
    const float SINE_CENTER_V = 0.0f;


    // --- 移动到起点并等待 ---
    // 1. 计算曲线的起点坐标 (最左侧的点)
    float start_u = SINE_CENTER_U - WAVE_WIDTH / 2.0f;
    //   正弦波在起点时，相位为0，sin(0)=0，所以v坐标就是基线的高度
    float start_v = SINE_CENTER_V;

    float start_target_x = start_u;
    float start_target_y = DISTANCE_TO_PAPER;
    float start_target_z = start_v;

    // 2. 计算起点PWM
    uint16_t start_pwm1, start_pwm2;
    if (calculate_pwm_from_coords(start_target_x, start_target_y, start_target_z, &start_pwm1, &start_pwm2)) {
        set_servos(start_pwm1, start_pwm2);
        mspm0_delay_ms(1000); // 等待1秒，确保云台已经到达起点
    }

    for (int i = 0; i <= NUM_SINE_STEPS; ++i) {
        
        // 1. 计算当前插值点的水平位置 u
        float u = start_u + ((float)i / NUM_SINE_STEPS) * WAVE_WIDTH;

        // 2. 使用正弦函数计算对应的垂直位置 v
        //    计算频率常数k，使得在总宽度width内正好包含num_cycles个周期
        float k = (NUM_CYCLES * kTwoPi) / WAVE_WIDTH;
        float angle_in_sine = k * (u - start_u); // u在整个宽度上移动，对应正弦函数的输入角度从0变化到num_cycles*2*PI
        float v = SINE_CENTER_V + WAVE_AMPLITUDE * sin(angle_in_sine);

        // 3. 将2D绘图坐标 (u,v) 映射到 3D空间坐标 (x,y,z)
        float target_x = u;
        float target_y = DISTANCE_TO_PAPER; // y坐标是固定的！
        float target_z = v;

        // 4. 调用逆解算函数，得到PWM值并驱动舵机
        uint16_t pwm1, pwm2;
        if (calculate_pwm_from_coords(target_x, target_y, target_z, &pwm1, &pwm2)) {
            set_servos(pwm1, pwm2);
        }
        
        // 5. 短暂延时以控制绘制速度
        mspm0_delay_ms(15); // 您可以根据需要调整这个值
    }
}
