#ifndef __SERVO_H
#define __SERVO_H

#include "ti_msp_dl_config.h"

void set_servo_1(uint32_t value);

void set_servo_2(uint32_t value);

void servo_calc(float x, float y);

bool calculate_pwm_from_coords(float x, float y, float z, uint16_t* out_pwm2, uint16_t* out_pwm1);

void loop_draw_square_on_plane();

void loop_draw_circle_on_plane();

void loop_draw_sine_wave();

#endif